export const environment = {
  production: false,
  BASE_API_URL: '',
  MOCK_SERVER: '',
  AUTH_TOKEN_KEY: '',
  USE_MOCKUP: false,
};
