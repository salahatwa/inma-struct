import { Component } from '@angular/core';

@Component({
  selector: 'pfm-footer',
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent {

}
