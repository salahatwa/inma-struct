import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { MenuitemComponent } from '../menuitem/menuitem.component';

@Component({
  selector: 'pfm-menu',
  imports: [CommonModule, MenuitemComponent, RouterModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.scss',
})
export class MenuComponent implements OnInit {
  model: MenuItem[] = [];

  ngOnInit() {
    this.model = [
      {
        label: 'Home',
        items: [
          { label: 'Dashboard', icon: 'pi pi-fw pi-home', routerLink: ['/'] },
        ],
      },
      {
        label: 'Main',
        icon: 'pi pi-fw pi-briefcase',
        routerLink: ['/main'],
        items: [
          {
            label: 'Configuration',
            icon: 'pi pi-fw pi-briefcase',
            routerLink: ['/configurations'],
          },
          {
            label: 'Aggregation Rules',
            icon: 'pi pi-fw pi-cog',
            routerLink: ['/aggregation-rules'],
          },
          {
            label: 'Classification Rules',
            icon: 'pi pi-fw pi-tags',
            routerLink: ['/classification-rules'],
          },
          {
            label: 'Classifier Types',
            icon: 'pi pi-fw pi-list',
            routerLink: ['/classifier-types'],
          },
          {
            label: 'Classifiers',
            icon: 'pi pi-fw pi-sitemap',
            routerLink: ['/classifiers'],
          },
          {
            label: 'Batches',
            icon: 'pi pi-fw pi-briefcase',
            routerLink: ['/batches'],
          },
          {
            label: 'Transactions',
            icon: 'pi pi-fw pi-clone',
            routerLink: ['/transactions'],
          },
          {
            label: 'SystemHealth',
            icon: 'pi pi-fw pi-heart',
            routerLink: ['/system-health'],
          },
          {
            label: 'Customer Databases',
            icon: 'pi pi-fw pi-database',
            routerLink: ['/customer-databases'],
          },
        ],
      },
    ];
  }
}
