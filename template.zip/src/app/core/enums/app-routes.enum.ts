export enum PfmRoutes {
    Configurations = 'configurations',
    CustomerDatabases = 'customer-databases',
    ClassifierTypes = 'classifier-types',
    Classifiers = 'classifiers',
    ClassificationRules = 'classification-rules',
    AggregationRules = 'aggregation-rules',
    Batches= 'batches',
    Transactions='transactions',
    SystemHealth='system-health',
    Views = 'views',
    NotFound = 'notfound',
}
