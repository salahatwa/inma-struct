import { HttpRequest, HttpEvent, HttpHandlerFn } from '@angular/common/http';
import { Observable } from 'rxjs';

export function CorsInterceptor(
  req: HttpRequest<unknown>,
  next: HttpHandlerFn,
): Observable<HttpEvent<unknown>> {
  console.log('CorsInterceptor intercepting request');
  console.log(req.headers.append('Access-Control-Allow-Origin', '*'));
  const clonedRequest = req.clone({
    headers: req.headers.append('Access-Control-Allow-Origin', '*'),
  });
  return next(clonedRequest);
}
