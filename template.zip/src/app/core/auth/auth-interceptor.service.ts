import { HttpErrorResponse, HttpEvent, HttpHandlerFn, HttpRequest } from "@angular/common/http";
import { inject } from "@angular/core";
import { Router } from "@angular/router";
import { catchError, Observable, throwError } from "rxjs";

function logout(): void {
  localStorage.removeItem('userDetails');
  localStorage.removeItem('authToken');
}

export function AuthInterceptor(req: HttpRequest<unknown>, next: HttpHandlerFn): Observable<HttpEvent<unknown>> {
  // Check if the request URL is the login endpoint
  const router = inject(Router);
  const isLoginEndpoint = req.url.endsWith('login');
  // If it's the login endpoint, just pass the request through
  if (isLoginEndpoint) {
    return next(req);
  }

  // Get the token from local storage
  const token = localStorage.getItem('authToken');
  // Clone the request and add the token to the headers if it exists
  if (token) {
    const authReq = req.clone({
      setHeaders: {
        Authorization: `${token}`,
      },
    });
    return next(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        // Handle HTTP 401 errors (Unauthorized)
        if (error.status === 401) {
          // Perform logout and redirect to login page
          logout();
          router.navigate(['/auth/login']);
        }
        // Pass the error along to the caller
        return throwError(error);
      }),
    );
  }
  return next(req);
}