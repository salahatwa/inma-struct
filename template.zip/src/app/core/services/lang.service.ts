import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs'; // Import BehaviorSubject from RxJS
import { Lang } from '../enums/lang.enum';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
    providedIn: 'root' // This service is provided globally
})
export class LangService {
    private readonly language: BehaviorSubject<string>;

    constructor(private readonly translate: TranslateService) {
        // Get the current language from localStorage, or default to 'en'
        const initialLang = localStorage.getItem(Lang.LocalStorageKey) ?? Lang.English;

        // Initialize the BehaviorSubject with the current language
        this.language = new BehaviorSubject(initialLang);

        // Set the initial language (and text direction) on app start
        this.updateBodyDirection(initialLang);
    }

    init(): void {
        this.translate.addLangs([Lang.Arabic, Lang.English]);
        this.translate.setDefaultLang(Lang.English);
        this.translate.use(this.getCurrentLang());
    }

    // Observable for language change (components can subscribe to this)
    get onLangChange() {
        return this.language;
    }

    // Get current language (either 'en' or 'ar')
    getCurrentLang(): string {
        return this.language.getValue();
    }

    // Set the current language and emit the change
    setCurrentLang(lang: string): void {
        localStorage.setItem(Lang.LocalStorageKey, lang); // Save the language to localStorage
        this.translate.setDefaultLang(lang);
        this.language.next(lang); // Emit the new language via the subject
    }

    // Check if current language is Arabic
    isArabic(): boolean {
        return this.getCurrentLang() === Lang.Arabic;
    }

    // Check if current language is English
    isEnglish(): boolean {
        return this.getCurrentLang() === Lang.English;
    }

    // Check if the current language is RTL
    isRTL(): boolean {
        return this.isArabic();
    }

    // Check if the current language is LTR
    isLTR(): boolean {
        return this.isEnglish();
    }

    // Toggle the language between Arabic and English
    toggleLang(): void {
        window.location.reload();
        const currentLang = this.getCurrentLang();
        const newLang = currentLang === Lang.English ? Lang.Arabic : Lang.English; // Toggle the language

        this.setCurrentLang(newLang); // Update the language
    }

    // Update the text direction (LTR/RTL) based on the current language
    private updateBodyDirection(lang: string): void {
        document.body.dir = lang === Lang.Arabic ? 'rtl' : 'ltr'; // Set direction to 'rtl' for Arabic, 'ltr' for others
    }
}
