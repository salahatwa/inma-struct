import { Component } from '@angular/core';

@Component({
    selector: 'pfm-classification-rules',
    templateUrl: './classification-rules.component.html',
    styleUrls: ['./classification-rules.component.scss'],
    standalone: true
})
export class ClassificationRulesComponent {}
