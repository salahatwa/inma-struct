import { Routes } from '@angular/router';
import { ClassificationRulesComponent } from './pages/classification-rules/classification-rules.component';

export default [{ path: '', component: ClassificationRulesComponent }] as Routes;
