import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { BatchesService } from '@features/batches/service/batches.service';
import { Batch } from '@shared/models/batch.model';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { ButtonModule } from 'primeng/button';
import { Page } from '@shared/models/page.model';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'pfm-batches',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TableModule,
    PaginatorModule,
    InputTextModule,
    CalendarModule,
    ButtonModule,
  ],
  providers: [BatchesService],
  templateUrl: './batches.component.html',
  styleUrls: ['./batches.component.scss'],
  standalone: true,
})
export class BatchesComponent {
  batches = signal<Batch[]>([]);
  page = signal<Page>({
    matchedRecords: 0,
    returnedRecords: 0,
    limit: 0,
    offset: 0,
  });

  limit = 50;
  pageNumber = 0;

  form!: FormGroup;

  constructor(private batchesService: BatchesService) {}

  ngOnInit() {
    this.form = new FormGroup({
      fromDate: new FormControl(new Date()),
      toDate: new FormControl(new Date()),
      batchId: new FormControl(''),
    });
  }

  search() {
    this.batchesService
      .getBatches(
        this.form.get('fromDate')?.value.toISOString().split('T')[0],
        this.form.get('toDate')?.value.toISOString().split('T')[0],
        this.form.get('batchId')?.value,
        this.limit,
        this.pageNumber,
      )
      .subscribe((res) => {
        this.page.set(res.page);
        this.batches.set(res.response);
      });
  }

  pageChange(event: any) {
    this.pageNumber = event.page + 1;
    this.search();
  }
}
