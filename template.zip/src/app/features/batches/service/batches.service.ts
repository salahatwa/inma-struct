import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Batch } from '@shared/models/batch.model';
import { environment } from 'environment';
import { catchError, map, throwError } from 'rxjs';
import { getBackendURL } from 'src/app/utils/environment.utils';
import BATCHES_URLS from './batches.url';

@Injectable({
  providedIn: 'root',
})
export class BatchesService {
  BASE_URL: string = `${getBackendURL(environment)}`;

  constructor(private http: HttpClient) {}

  getBatches(
    fromDate: string,
    toDate: string,
    batchId?: string,
    limit?: number,
    offset?: number,
  ) {
    return this.http
      .get(`${this.BASE_URL}/${BATCHES_URLS.GET_BATCHES}`, {
        params: {
          limit: limit ?? 50,
          offset: offset ?? 0,
          'from-date': fromDate,
          'to-date': toDate,
          'batch-id': batchId ?? '',
        },
      })
      .pipe(
        map((res: any) => res),
        catchError((err) => {
          if (err?.error?.status) {
            err.error['message'] = err?.error?.status?.desc;
          }
          return throwError(() => (err?.error ? err?.error : err));
        }),
      );
  }

  getBatch(batchId: string) {
    return this.http
      .get(`${this.BASE_URL}/${BATCHES_URLS.GET_BATCH(batchId)}`)
      .pipe(
        map((res: any) => res as Batch),
        catchError((err) => {
          if (err?.error?.status) {
            err.error['message'] = err?.error?.status?.desc;
          }
          return throwError(() => (err?.error ? err?.error : err));
        }),
      );
  }
}
