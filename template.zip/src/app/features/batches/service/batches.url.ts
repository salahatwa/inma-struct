const BATCHES_URLS = {
  GET_BATCH: (batchId: string) => `/v1/ivr/callback-status/${batchId}`,
  GET_BATCHES: 'v1/report/batch-info',
};
export default BATCHES_URLS;
