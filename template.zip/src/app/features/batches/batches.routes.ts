import { Routes } from '@angular/router';
import { BatchesComponent } from './pages/batches/batches.component';

export default [{ path: '', component: BatchesComponent }] as Routes;
