import { Routes } from '@angular/router';
import { ConfigurationsComponent } from './pages/configurations/configurations.component';

export default [{ path: '', component: ConfigurationsComponent }] as Routes;
