import { Component, OnInit, signal, ViewChild } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table, TableModule } from 'primeng/table';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { ToolbarModule } from 'primeng/toolbar';
import { RatingModule } from 'primeng/rating';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';
import { SelectModule } from 'primeng/select';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { ConfigurationService } from '@features/configurations/service/configuration.service';

import { FileUploadModule } from 'primeng/fileupload';

import { ProgressBarModule } from 'primeng/progressbar';
import { HttpEventType } from '@angular/common/http';
import { Configuration } from '@shared/models/configuration.model';

interface Column {
  field: string;
  header: string;
  customExportHeader?: string;
}

@Component({
  selector: 'pfm-configurations',
  imports: [
    CommonModule,
    TableModule,
    FormsModule,
    ButtonModule,
    FileUploadModule,
    RippleModule,
    ToastModule,
    ToolbarModule,
    RatingModule,
    InputTextModule,
    TextareaModule,
    SelectModule,
    RadioButtonModule,
    InputNumberModule,
    DialogModule,
    TagModule,
    InputIconModule,
    IconFieldModule,
    ConfirmDialogModule,
    ProgressBarModule,
    ToggleSwitchModule
  ],
  providers: [MessageService, ConfigurationService, ConfirmationService],
  templateUrl: './configurations.component.html',
  styleUrl: './configurations.component.scss'
})
export class ConfigurationsComponent implements OnInit {
  configurationDialog: boolean = false;

  configurations = signal<Configuration[]>([]);

  configuration!: Configuration;

  selectedConfigurations!: Configuration[] | null;

  submitted: boolean = false;

  statuses!: unknown[];

  @ViewChild('dt') dt!: Table;

  cols!: Column[];
  fileProgress: number = 0;
  showLoading: boolean = false;
  checked: boolean = true;
  loadingConfigs: boolean = false;
  logs: any = [];

  constructor(
    private readonly configurationService: ConfigurationService,
    private readonly messageService: MessageService,
    private readonly confirmationService: ConfirmationService
  ) { }

  exportCSV() {
    this.dt.exportCSV();
  }

  ngOnInit() {
    this.getconfigs()
    // this.loadDemoData();
  }

  getconfigs(){
    this.loadingConfigs = true;
    this.configurationService.getConfigs().subscribe((res:any)=>{
      this.loadingConfigs = false;
      this.configurations.set(res?.response);
    },(err:any)=>{
      this.loadingConfigs = false;
    })
  }



  loadDemoData() {
    this.configurationService.getConfigurations().then((data) => {
      this.configurations.set(data);
    });

    this.statuses = [
      { label: 'ACTIVE', value: 'active' },
      { label: 'INACTIVE', value: 'inactive' }
    ];

    this.cols = [
      { field: 'code', header: 'Code', customExportHeader: 'Configuration Code' },
      { field: 'name', header: 'Name' }
    ];

  }

  onGlobalFilter(table: Table, event: Event) {
    table.filterGlobal((event.target as HTMLInputElement).value, 'contains');
  }

  showToast() {
    this.messageService.addAll([
      { severity: 'success', summary: 'Done!', detail: 'Uploaded successfully' },
    ]);
 }

  onConfigUpload(event: any) {
    this.showLoading = true;
    this.fileProgress = 0;
    const file = event.files[0];

    const myInterval = setInterval(()=>{
      this.fileProgress++;
      console.log(this.fileProgress);
    }, 250);
    
    this.configurationService.uploadConigXls(file).subscribe(event => {
      switch (event.type) {
        case HttpEventType.UploadProgress:

        this.fileProgress = (event?.total && event?.total )? event?.loaded  / event?.total * 100 : 0;
          // console.log('Uploaded ' + event.loaded + ' out of ' + event.total + ' bytes');
          break;
        case HttpEventType.Response:
          clearInterval(myInterval);
          console.log('Finished uploading!');
          console.log(event)
          this.fileProgress = 100;
          this.showToast();
          this.getconfigs();

          setTimeout(() => {
            this.fileProgress = 0;
            this.showLoading = false;

          }, 3000);

          break;
      }
    });
  }

  openNew() {
    this.configuration = {};
    this.submitted = false;
    this.configurationDialog = true;
  }

  editConfiguration(configuration: Configuration) {
    this.configurationService.getConfigDetails(configuration?.id || '').subscribe((res:any)=>{
      console.log(res);
      this.configuration = { ...configuration };
      this.configurationDialog = true;
      this.logs = res?.response?.logs
    })
  }

  enableAndDisable(configuration:Configuration){
    if(configuration?.status != 'completed'){
      this.messageService.addAll([{
        severity: 'warn',
        summary: 'Warning',
        detail: 'Configuration must be completed status to be enabled'
      }]);
      setTimeout(() => {
        configuration.enabled = !configuration.enabled;
        
      }, 0);
      return;
    }
    if(!configuration?.enabled){
      setTimeout(() => {
        configuration.enabled = !configuration.enabled;
        
      }, 0);
      return
    }
    this.confirmationService.confirm({
      message: 'Are you sure you want to enable the selected configuration?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      reject:() => {
        configuration.enabled = !configuration.enabled;
      },
      accept: () => {

        this.loadingConfigs = true;
        this.configurationService.enableDisableConfig(configuration?.id||'').subscribe((res:any)=>{
          this.getconfigs();
          this.messageService.addAll([{
            severity: 'success',
            summary: 'Successful',
            detail: 'Configuration enabled'
          }]);
          
        },(err)=>{

          this.loadingConfigs = false;
          configuration.enabled = !configuration.enabled;
        })
      }
    });
  }

  deleteSelectedConfigurations() {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete the selected configuration?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.configurations.set(this.configurations().filter((val) => !this.selectedConfigurations?.includes(val)));
        this.selectedConfigurations = null;
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Configurations Deleted',
          life: 3000
        });
      }
    });
  }

  hideDialog() {
    this.configurationDialog = false;
    this.submitted = false;
  }

  deleteConfiguration(configuration: Configuration) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete ' + configuration.fileName + '?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.configurations.set(this.configurations().filter((val) => val.id !== configuration.id));
        this.configuration = {};
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'configuration Deleted',
          life: 3000
        });
      }
    });
  }

  findIndexById(id: string): number {
    let index = -1;

    for (let i = 0; i < this.configurations().length; i++) {
      if (this.configurations()[i].id === id) {
        index = i;
        break;
      }
    }

    return index;
  }

  createId(): string {
    let id = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < 5; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return id;
  }

  getSeverity(status: string) {
    switch (status) {
      case 'INSTOCK':
        return 'success';
      case 'LOWSTOCK':
        return 'warn';
      case 'OUTOFSTOCK':
        return 'danger';
      default:
        return 'info';
    }
  }

  saveConfiguration() {
    this.submitted = true;
    const _configurations = this.configurations();

    if (this.configuration.fileName?.trim()) {
      if (this.configuration.id) {
        _configurations[this.findIndexById(this.configuration.id)] = this.configuration;
        this.configurations.set([..._configurations]);
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Configuration Updated',
          life: 3000
        });
      } else {
        this.configuration.id = this.createId();
        this.messageService.add({
          severity: 'success',
          summary: 'Successful',
          detail: 'Configuration Created',
          life: 3000
        });
        this.configurations.set([..._configurations, this.configuration]);
      }

      this.configurationDialog = false;
      this.configuration = {};
    }
  }
}
