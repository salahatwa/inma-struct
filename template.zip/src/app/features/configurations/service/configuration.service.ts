import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Configuration } from '@shared/models/configuration.model';
import { environment } from 'environment';
import { catchError, throwError } from 'rxjs';
import { getBackendURL } from 'src/app/utils/environment.utils';

@Injectable({
  providedIn: 'root'
})
export class ConfigurationService {

  configurationNames: string[] = [
    'Configuration One',
    'Configuration Two',
    'Configuration Three',
    'Configuration Four',
    'Configuration Five',
    'Configuration Six',
    'Configuration Seven',
    'Configuration Eight',
    'Configuration Nine',
    'Configuration Ten',
    'Configuration Eleven',
    'Configuration Twelve',
    'Configuration Thirteen',
    'Configuration Fourteen',
    'Configuration Fifteen',
    'Configuration Sixteen',
    'Configuration Seventeen',
    'Configuration Eighteen',
    'Configuration Nineteen',
    'Configuration Twenty'
  ];

  status: string[] = ['ACTIVE', 'INACTIVE'];

  getConfigurationsData(){
    const configurations: Configuration[] = [];

    for (let i = 0; i < 50; i++) {
      configurations.push(this.generateConfiguration());
    }

    return configurations;
  }

  BASE_URL: string = `${getBackendURL(environment)}`;

  constructor(private http: HttpClient) { }



  uploadConigXls(file: File) {

    const formData: FormData = new FormData();
    formData.append('configurationFile', file);
    return this.http.post(`${this.BASE_URL}/configuration/upload`, formData , {
      reportProgress: true,
      observe: 'events',
    }).pipe(
      catchError((err) => {
        if(err?.error?.status){
          err.error['message'] = err?.error?.status?.desc;
        }
        return throwError(() => (err?.error ? err?.error : err));
      }),
    );
  }



  getConfigs() {
    return this.http.get(`${this.BASE_URL}/configuration`).pipe(
      catchError((err) => {
        if(err?.error?.status){
          err.error['message'] = err?.error?.status?.desc;
        }
        return throwError(() => (err?.error ? err?.error : err));
      }),
    );
  }

  enableDisableConfig(id:string) {
    return this.http.post(`${this.BASE_URL}/configuration/${id}/enable`,{}).pipe(
      catchError((err) => {
        if(err?.error?.status){
          err.error['message'] = err?.error?.status?.desc;
        }
        return throwError(() => (err?.error ? err?.error : err));
      }),
    );
  }


  getConfigDetails(id:string) {
    return this.http.get(`${this.BASE_URL}/configuration/${id}?includeLogs=true`).pipe(
      catchError((err) => {
        if(err?.error?.status){
          err.error['message'] = err?.error?.status?.desc;
        }
        return throwError(() => (err?.error ? err?.error : err));
      }),
    );
  }

  getConfigurationsMini() {
    return Promise.resolve(this.getConfigurationsData().slice(0, 5));
  }

  getConfigurationsSmall() {
    return Promise.resolve(this.getConfigurationsData().slice(0, 10));
  }

  getConfigurations() {
    return Promise.resolve(this.getConfigurationsData());
  }

  generateConfiguration(): Configuration {
    const configuration: Configuration = {
      id: this.generateId(),
      status: ''
    };

    return configuration;
  }

  generateCode() {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < 8; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
  }

  generateId() {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < 5; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
  }

  generateName() {
    return this.configurationNames[Math.floor(Math.random() * this.configurationNames.length)];
  }

  generateStatus() {
    return this.status[Math.floor(Math.random() * this.status.length)];
  }
}
