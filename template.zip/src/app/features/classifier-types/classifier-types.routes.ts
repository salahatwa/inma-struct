import { Routes } from '@angular/router';
import { ClassifierTypesComponent } from './pages/classifier-types/classifier-types.component';

export default [{ path: '', component: ClassifierTypesComponent }] as Routes;
