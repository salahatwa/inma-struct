import { Component } from '@angular/core';

@Component({
    selector: 'pfm-classifier-types',
    templateUrl: './classifier-types.component.html',
    styleUrls: ['./classifier-types.component.scss'],
    standalone: true
})
export class ClassifierTypesComponent {}
