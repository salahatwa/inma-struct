import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassifierTypesComponent } from './classifier-types.component';

describe('ClassifierTypesComponent', () => {
    let component: ClassifierTypesComponent;
    let fixture: ComponentFixture<ClassifierTypesComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [ClassifierTypesComponent]
        });
        fixture = TestBed.createComponent(ClassifierTypesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
