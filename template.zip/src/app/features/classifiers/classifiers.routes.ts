import { Routes } from '@angular/router';
import { ClassifiersComponent } from './pages/classifiers/classifiers.component';

export default [{ path: '', component: ClassifiersComponent }] as Routes;
