import { Component } from '@angular/core';

@Component({
    selector: 'pfm-classifiers',
    templateUrl: './classifiers.component.html',
    styleUrls: ['./classifiers.component.scss'],
    standalone: true
})
export class ClassifiersComponent {}
