import { Routes } from '@angular/router';
import { TransactionsComponent } from './pages/transactions/transactions.component';

export default [{ path: '', component: TransactionsComponent }] as Routes;
