import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { TransactionsService } from '@features/transactions/service/transactions.service';
import { Batch } from '@shared/models/batch.model';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { Page } from '@shared/models/page.model';
import { InputTextModule } from 'primeng/inputtext';

@Component({
  selector: 'pfm-transactions',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TableModule,
    PaginatorModule,
    InputTextModule,
    DropdownModule,
    CheckboxModule,
    CalendarModule,
    ButtonModule,
  ],
  providers: [TransactionsService],
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss'],
  standalone: true,
})
export class TransactionsComponent {
  transactions = signal<Batch[]>([]);
  stages: string[] = 
  [
    'ENRICHMENT',
    'CORE_CLASSIFICATION',
    'CORE_AGGREGATION_PREPARE',
    'CORE_AGGREGATION_APPLY',
    'RETAIL_CLASSIFICATION',
    'RETAIL_AGGREGATION_PREPARE',
    'RETAIL_AGGREGATION_APPLY',
    'CORPORATE_CLASSIFICATION',
    'CORPORATE_AGGREGATION_PREPARE',
    'CORPORATE_AGGREGATION_APPLY',
    'CUSTOMER_CLASSIFICATION',
    'CUSTOMER_AGGREGATION_PREPARE',
    'CUSTOMER_AGGREGATION_APPLY',
    'CUSTOMER_NOTIFICATIONS',
  ] as const;
  
  ;
  page = signal<Page>({
    matchedRecords: 0,
    returnedRecords: 0,
    limit: 0,
    offset: 0,
  });

  limit = 50;
  pageNumber = 0;

  form!: FormGroup;

  constructor(private transactionsService: TransactionsService) {}

  ngOnInit() {
    this.form = new FormGroup({
      fromDate: new FormControl(''),
      toDate: new FormControl(''),
      batchId: new FormControl(''),
      stage: new FormControl(''),
      failed: new FormControl(''),
      cif: new FormControl(''),
      transactionId: new FormControl(''),
    });
  }

  search() {
    this.transactionsService
      .getTransactions(
        this.form.get('fromDate')?.value.toISOString().split('T')[0],
        this.form.get('toDate')?.value.toISOString().split('T')[0],
        this.form.get('batchId')?.value,
        this.form.get('stage')?.value,
        this.form.get('cif')?.value,
        this.form.get('transactionId')?.value,
        this.form.get('failed')?.value,
        this.limit,
        this.pageNumber,
      )
      .subscribe((res) => {
        this.page.set(res.page);
        this.transactions.set(res.response);
      });
  }

  pageChange(event: any) {
    this.pageNumber = event.page + 1;
    this.search();
  }
}
