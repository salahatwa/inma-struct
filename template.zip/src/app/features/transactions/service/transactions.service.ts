import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Transaction } from '@shared/models/transaction.model';
import { environment } from 'environment';
import { catchError, map, throwError } from 'rxjs';
import { getBackendURL } from 'src/app/utils/environment.utils';
import TRANSACTIONS_URLS from './transactions.url';

@Injectable({
  providedIn: 'root',
})
export class TransactionsService {
  BASE_URL: string = `${getBackendURL(environment)}`;

  constructor(private http: HttpClient) {}

  getTransactions(
    fromDate: string,
    toDate: string,
    batchId?: string,
    stage?: string,
    cif?: string,
    transactionId?: string,
    failed?: boolean,
    limit?: number,
    offset?: number,
  ) {
    return this.http
      .get(`${this.BASE_URL}/${TRANSACTIONS_URLS.GET_TRANSACTIONS}`, {
        params: {
          limit: limit ?? 50,
          offset: offset ?? 0,
          'from-date': fromDate,
          'to-date': toDate,
          ...(batchId ? { 'batch-id': batchId } : {}),
          ...(stage ? { 'stage': stage } : {}),
          ...(cif ? { 'cif': cif } : {}),
          ...(transactionId ? { 'transaction-id': transactionId } : {}),
          ...(failed ? { failed: true } : {}),
        },
      })
      .pipe(
        map((res: any) => res),
        catchError((err) => {
          if (err?.error?.status) {
            err.error['message'] = err?.error?.status?.desc;
          }
          return throwError(() => (err?.error ? err?.error : err));
        }),
      );
  }
}
