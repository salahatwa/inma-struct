const TRANSACTIONS_URLS = {
  GET_TRANSACTIONS: 'v1/report/transaction',
};
export default TRANSACTIONS_URLS;
