import { Component } from '@angular/core';

@Component({
    selector: 'pfm-views',
    templateUrl: './views.component.html',
    styleUrls: ['./views.component.scss'],
    standalone: true
})
export class ViewsComponent {}
