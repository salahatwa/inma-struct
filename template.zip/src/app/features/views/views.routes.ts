import { Routes } from '@angular/router';
import { ViewsComponent } from './pages/views/views.component';

export default [{ path: '', component: ViewsComponent }] as Routes;
