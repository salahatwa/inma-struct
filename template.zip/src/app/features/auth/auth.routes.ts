import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { ErrorComponent } from './pages/error/error.component';
import { AccessComponent } from './pages/access/access.component';

export default [
    { path: 'login', component: LoginComponent },
    { path: 'error', component: ErrorComponent },
    { path: 'access', component: AccessComponent },
] as Routes;
