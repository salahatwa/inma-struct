import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { RippleModule } from 'primeng/ripple';

@Component({
    selector: 'pfm-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    imports: [RouterModule, ButtonModule, InputTextModule, PasswordModule, CheckboxModule, FormsModule, RippleModule],
    standalone: true
})
export class LoginComponent {

    email: string = '';

    password: string = '';

    checked: boolean = false;
}
