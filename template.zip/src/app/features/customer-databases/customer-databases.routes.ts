import { Routes } from '@angular/router';
import { CustomerDatabasesComponent } from './pages/customer-databases/customer-databases.component';

export default [{ path: '', component: CustomerDatabasesComponent }] as Routes;
