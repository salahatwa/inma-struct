import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerDatabasesComponent } from './customer-databases.component';

describe('CustomerDatabasesComponent', () => {
    let component: CustomerDatabasesComponent;
    let fixture: ComponentFixture<CustomerDatabasesComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [CustomerDatabasesComponent]
        });
        fixture = TestBed.createComponent(CustomerDatabasesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
