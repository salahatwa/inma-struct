import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
    selector: 'pfm-customer-databases',
    templateUrl: './customer-databases.component.html',
    styleUrls: ['./customer-databases.component.scss'],
    standalone: true,
    imports: [CommonModule]
})
export class CustomerDatabasesComponent {}
