import { Component } from '@angular/core';

@Component({
    selector: 'pfm-system-health',
    templateUrl: './system-health.component.html',
    styleUrls: ['./system-health.component.scss'],
    standalone: true
})
export class SystemHealthComponent {}
