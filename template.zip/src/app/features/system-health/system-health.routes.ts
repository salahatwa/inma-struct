import { Routes } from '@angular/router';
import { SystemHealthComponent } from './pages/system-health/system-health.component';

export default [{ path: '', component: SystemHealthComponent }] as Routes;
