import { Routes } from '@angular/router';
import { AggregationRulesComponent } from './pages/aggregation-rules/aggregation-rules.component';

export default [{ path: '', component: AggregationRulesComponent }] as Routes;
