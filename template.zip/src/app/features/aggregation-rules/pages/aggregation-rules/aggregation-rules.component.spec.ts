import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggregationRulesComponent } from './aggregation-rules.component';

describe('AggregationRulesComponent', () => {
    let component: AggregationRulesComponent;
    let fixture: ComponentFixture<AggregationRulesComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [AggregationRulesComponent]
        });
        fixture = TestBed.createComponent(AggregationRulesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
