import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LangService } from '@core/services/lang.service';
import { /* TranslatePipe, */ TranslateService } from '@ngx-translate/core';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'pfm-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    standalone: true,
    imports: [RouterModule, /* TranslatePipe, */ ButtonModule]
})
export class AppComponent {
    title = 'pfm-admin-web-ng';

    constructor(
        private readonly translate: TranslateService,
        private readonly langService: LangService
    ) {
        this.langService.init();
    }

    switchLanguage() {
        this.langService.toggleLang();
    }
}
