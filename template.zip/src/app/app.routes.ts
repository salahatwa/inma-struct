import { Routes } from '@angular/router';
import { PfmRoutes } from './core/enums/app-routes.enum';
import { LayoutComponent } from '@core/components/layout/layout.component';

export const appRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: PfmRoutes.Configurations,
        loadChildren: () =>
          import('./features/configurations/configurations.routes'),
      },
      {
        path: PfmRoutes.CustomerDatabases,
        loadChildren: () =>
          import('./features/customer-databases/customer-databases.routes'),
      },
      {
        path: PfmRoutes.ClassifierTypes,
        loadChildren: () =>
          import('./features/classifier-types/classifier-types.routes'),
      },
      {
        path: PfmRoutes.Classifiers,
        loadChildren: () => import('./features/classifiers/classifiers.routes'),
      },
      {
        path: PfmRoutes.ClassificationRules,
        loadChildren: () =>
          import('./features/classification-rules/classification-rules.routes'),
      },
      {
        path: PfmRoutes.AggregationRules,
        loadChildren: () =>
          import('./features/aggregation-rules/aggregation-rules.routes'),
      },
      {
        path: PfmRoutes.Batches,
        loadChildren: () => import('./features/batches/batches.routes'),
      },
      {
        path: PfmRoutes.Transactions,
        loadChildren: () => import('./features/transactions/transactions.routes'),
      },
      {
        path: PfmRoutes.SystemHealth,
        loadChildren: () => import('./features/system-health/system-health.routes'),
      },
      {
        path: PfmRoutes.Views,
        loadChildren: () => import('./features/views/views.routes'),
      },
      // system health
      // reporting
    ],
  },
  {
    path: PfmRoutes.NotFound,
    loadChildren: () => import('./features/not-found/not-found.routes'),
  },
  { path: 'auth', loadChildren: () => import('./features/auth/auth.routes') },
  { path: '**', redirectTo: `/${PfmRoutes.NotFound}` },
];
