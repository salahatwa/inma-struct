export interface Batch {
  id: string;
  identifier: string;
  creationTime: Date;
  numberOfTransaction: number;
}
