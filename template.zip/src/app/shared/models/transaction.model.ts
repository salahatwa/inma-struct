export interface Transaction {
  id: string;
  identifier: string;
  creationTime: Date;
  numberOfTransaction: number;
}
