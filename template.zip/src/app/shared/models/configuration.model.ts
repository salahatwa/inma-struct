export interface Configuration {
  id?: string;
  endTime?: string;
  fileName?: string;
  executionTime?: string;
  startTime?: string;
  status?: string;
  enabled?: boolean;
}