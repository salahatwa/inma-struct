export interface Page {
  matchedRecords: number;
  returnedRecords: number;
  limit: number;
  offset: number;
}
