export const getBackendURL = (env: {
  production: boolean;
  BASE_API_URL: string;
  MOCK_SERVER: string;
  AUTH_TOKEN_KEY: string;
  USE_MOCKUP: boolean;
}): string => {
  if (env.USE_MOCKUP) {
    return env.MOCK_SERVER;
  } else {
    return env.BASE_API_URL;
  }
};
