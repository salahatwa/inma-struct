export const environment = {
  production: false,
  BASE_API_URL: 'https://pfm-admin-bo-be-svc-dev-common-assets-dev.apps.ocpnp.alinma.internal/pfm-admin-bo-be-svc',
  MOCK_SERVER: '',
  AUTH_TOKEN_KEY: '',
  USE_MOCKUP: false,
};
