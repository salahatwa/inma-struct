/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: ['class', '[class="pfm-dark"]'],
    content: ['./src/**/*.{html,ts,scss,css}', './index.html'],
    theme: {
        extend: {},
        screens: {
            sm: '576px',
            md: '768px',
            lg: '992px',
            xl: '1200px',
            '2xl': '1920px'
        }
    },
    plugins: [require('tailwindcss-primeui')]
};
