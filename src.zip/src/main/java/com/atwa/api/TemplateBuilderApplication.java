package com.atwa.api;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ironsoftware.ironpdf.License;
import com.ironsoftware.ironpdf.PdfDocument;
import com.ironsoftware.ironpdf.render.ChromePdfRenderOptions;
import com.ironsoftware.ironpdf.render.FitToPaperModes;
import com.ironsoftware.ironpdf.render.PaperOrientation;
import com.ironsoftware.ironpdf.render.PaperSize;
import com.ironsoftware.ironpdf.render.WaitFor;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType.LaunchOptions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Page.PdfOptions;
import com.microsoft.playwright.Playwright;

@SpringBootApplication
public class TemplateBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateBuilderApplication.class, args);

		System.out.println("Start");

//		System.out.println(gen(getResourceFileAsString("reports/pag1/index.html")));
//		free(getResourceFileAsString("reports/pag1/index.html"));

		List<String> items = new ArrayList<>();
		items.add(getResourceFileAsString("reports/contract/1.html"));
		items.add(getResourceFileAsString("reports/contract/2.html"));

		Map<String, Object> model = new HashMap<>();
		model.put("user", "Salah Atwa");

		try {
			xhtmlToPdf(items, model, new FileOutputStream("final result.pdf"));
//			lic();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static List<InputStream> xhtmlToPdf(List<String> pages, Map<String, Object> model,
			OutputStream outputStream) throws IOException {
		List<InputStream> inputPdfList = new ArrayList<InputStream>();

		try (Playwright playwright = Playwright.create()) {
			LaunchOptions d = new LaunchOptions();
			d.setArgs(Arrays.asList("--disable-web-security"));
			Browser browser = playwright.chromium().launch(d);

			for (String pageContent : pages) {
				Page page = browser.newPage();
				page.setContent(PlaceholderEngine.process(pageContent, model));

				PdfOptions s = new PdfOptions();
				s.setPrintBackground(true);
				s.setPreferCSSPageSize(true);
				s.setFormat("A4");
				byte[] result = page.pdf(s); // parse website and return pdf

				inputPdfList.add(new ByteArrayInputStream(result));
			}

			browser.close();
		}

		try {
			PDFMergeUtility.mergePdfFiles(inputPdfList, outputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return inputPdfList;
	}

	public static void lic() throws IOException {
		ChromePdfRenderOptions renderOptions = new ChromePdfRenderOptions();
		renderOptions.setWaitFor(new WaitFor(500));
		renderOptions.setFitToPaperMode(FitToPaperModes.AutomaticFit);
		renderOptions.setPaperOrientation(PaperOrientation.PORTRAIT);
//		renderOptions.set
		renderOptions.setPaperSize(PaperSize.A4);
		renderOptions.setMarginBottom(5);
		renderOptions.setMarginLeft(5);
		renderOptions.setMarginTop(5);
		renderOptions.setMarginRight(5);
//		renderOptions.se

		PdfDocument pdfFromHtmlString = PdfDocument.renderHtmlAsPdf(getResourceFileAsString("reports/contract/2.html"),
				renderOptions);
		License.setLicenseKey(
				"IRONSUITE.SALAHSAYEDATWA.GMAIL.COM.6053-57AA5ABD8B-BO55H6JJVUUREUPM-XWW4DJFFTRV5-KVH23V2M6S64-QCSGCO53KC5V-IRSXA5YQBAEQ-2QQLOXQ5HX2E-ZG3RZP-T4REIBR5MKWNUA-DEPLOYMENT.TRIAL-QH2V46.TRIAL.EXPIRES.15.OCT.2024");

		pdfFromHtmlString.saveAs(Paths.get("markup_with_assets.pdf"));
	}

	public static String getResourceFileAsString(String fileName) {
		InputStream is = getResourceFileAsInputStream(fileName);
		if (is != null) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			return (String) reader.lines().collect(Collectors.joining(System.lineSeparator()));
		} else {
			throw new RuntimeException("resource not found");
		}
	}

	public static InputStream getResourceFileAsInputStream(String fileName) {
		ClassLoader classLoader = TemplateBuilderApplication.class.getClassLoader();
		return classLoader.getResourceAsStream(fileName);
	}
}
