package com.atwa.api;

import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;

public class PlaceholderEngine {

	private Configuration freemarkerConfig;

	public static String process(String template, Map<String, Object> model) {

		String result = template;
		try {
			String templateKey = "Tmpl" + System.currentTimeMillis();

			StringTemplateLoader stringLoader = new StringTemplateLoader();

			stringLoader.putTemplate(templateKey, template);
			Configuration cfg = new Configuration();
			cfg.setTemplateLoader(stringLoader);
			Template t = cfg.getTemplate(templateKey);

			Writer out = new StringWriter();
			t.process(model, out);

			return out.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static List<String> process(List<String> templates, Map<String, Object> model) {

		List<String> result = new ArrayList<>();
		try {

			StringTemplateLoader stringLoader = new StringTemplateLoader();

			int i = 0;
			for (String template : templates) {
				stringLoader.putTemplate("TMPL" + i, template);
				i++;
			}

			Configuration cfg = new Configuration();
			cfg.setTemplateLoader(stringLoader);

			int j = 0;
			for (String item : templates) {
				Template t = cfg.getTemplate("TMPL" + j);
				Writer out = new StringWriter();
				t.process(model, out);
				result.add(out.toString());
				j++;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}
}
